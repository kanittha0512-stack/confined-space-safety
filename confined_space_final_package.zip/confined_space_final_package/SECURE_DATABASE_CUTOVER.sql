-- รันคำสั่งนี้หลังจาก deploy Netlify Functions และตั้งค่า Environment variables แล้วเท่านั้น
-- ไม่ลบแถวข้อมูลเดิมใน safety_app_state

-- ปิดช่องทางเขียนโดยตรงจาก browser/anon และผู้ใช้ authenticated
DROP POLICY IF EXISTS "public write safety state" ON public.safety_app_state;
REVOKE INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER ON TABLE public.safety_app_state FROM anon, authenticated;
GRANT SELECT ON TABLE public.safety_app_state TO anon, authenticated;

-- ตารางเก็บ hash ไม่ให้ client อ่านหรือแก้โดยตรง
REVOKE ALL ON TABLE public.inspector_access_config FROM anon, authenticated;

-- การตรวจรหัสจะทำใน Netlify Function ด้วย service-role key; ปิด RPC สาธารณะเพื่อไม่ให้เดารหัสผ่าน RPC ได้
REVOKE ALL ON FUNCTION public.verify_inspector_code(text) FROM PUBLIC, anon, authenticated;

-- คง RLS เปิดไว้; policy อ่านสาธารณะเดิมของ safety_app_state สามารถคงอยู่ได้หากต้องการให้ผู้ชมอ่านข้อมูลได้
