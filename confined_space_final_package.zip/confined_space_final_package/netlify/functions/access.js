const crypto = require('crypto');
const json = (statusCode, body) => ({ statusCode, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }, body: JSON.stringify(body) });
function sign(payload, secret) { const encoded=Buffer.from(JSON.stringify(payload)).toString('base64url'); const sig=crypto.createHmac('sha256',secret).update(encoded).digest('base64url'); return `${encoded}.${sig}`; }
exports.handler = async (event) => {
 if(event.httpMethod!=='POST') return json(405,{error:'Method not allowed'});
 const url=process.env.SUPABASE_URL, key=process.env.SUPABASE_SERVICE_ROLE_KEY, secret=process.env.ACCESS_TOKEN_SECRET;
 if(!url||!key||!secret||!process.env.ADMIN_ACCESS_CODE) return json(500,{error:'ตั้งค่า Environment variables ไม่ครบ (รวม ADMIN_ACCESS_CODE)'});
 let code; try{code=String(JSON.parse(event.body||'{}').code||'').trim()}catch{return json(400,{error:'ข้อมูลคำขอไม่ถูกต้อง'})}
 if(!code||code.length>200) return json(400,{error:'กรุณากรอกรหัสเข้าตรวจสอบ'});
 try {
  let role='';
  if (code === process.env.ADMIN_ACCESS_CODE) role='admin';
  else {
   const res=await fetch(`${url}/rest/v1/inspector_access_config?select=code_hash&id=eq.1`,{headers:{apikey:key,Authorization:`Bearer ${key}`}});
   if(!res.ok) return json(502,{error:'ตรวจสอบรหัสกับฐานข้อมูลไม่สำเร็จ'});
   const rows=await res.json(); const actual=crypto.createHash('sha256').update(code,'utf8').digest('hex'); const stored=rows?.[0]?.code_hash||''; const a=Buffer.from(actual),b=Buffer.from(stored);
   if(a.length===b.length&&crypto.timingSafeEqual(a,b)) role='inspector';
  }
  if(!role) return json(401,{error:'Invalid access code'});
  const now=Math.floor(Date.now()/1000); const token=sign({iat:now,exp:now+8*60*60,scope:'safety-inspector',role},secret);
  return json(200,{token,role,expiresIn:28800});
 } catch(e){console.error('access function error',e);return json(500,{error:'เกิดข้อผิดพลาดในการตรวจรหัส'})}
};
