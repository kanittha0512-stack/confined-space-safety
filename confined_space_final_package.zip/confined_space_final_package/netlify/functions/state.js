const crypto = require('crypto');
const json = (statusCode, body) => ({ statusCode, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }, body: JSON.stringify(body) });
function tokenPayload(token, secret) {
 if(!token||!secret)return null; const parts=token.split('.'); if(parts.length!==2)return null;
 const expected=crypto.createHmac('sha256',secret).update(parts[0]).digest(); let got; try{got=Buffer.from(parts[1],'base64url')}catch{return null}
 if(expected.length!==got.length||!crypto.timingSafeEqual(expected,got))return null;
 try{const p=JSON.parse(Buffer.from(parts[0],'base64url').toString('utf8'));return p.scope==='safety-inspector'&&Number(p.exp)>Math.floor(Date.now()/1000)?p:null}catch{return null}
}
exports.handler=async(event)=>{
 if(!['GET','POST'].includes(event.httpMethod))return json(405,{error:'Method not allowed'});
 const auth=event.headers.authorization||event.headers.Authorization||'';const token=auth.startsWith('Bearer ')?auth.slice(7):'';const payload=tokenPayload(token,process.env.ACCESS_TOKEN_SECRET);
 if(event.httpMethod==='POST'&&!payload)return json(401,{error:'รหัสยืนยันหมดอายุหรือไม่ถูกต้อง กรุณากรอกรหัสเข้าตรวจสอบใหม่'});
 const url=process.env.SUPABASE_URL,key=process.env.SUPABASE_SERVICE_ROLE_KEY;if(!url||!key)return json(500,{error:'เว็บไซต์ยังตั้งค่า Environment variables ไม่ครบ'});
 const endpoint=`${url}/rest/v1/safety_app_state`;const headers={apikey:key,Authorization:`Bearer ${key}`,'Content-Type':'application/json'};
 try{
  if(event.httpMethod==='GET'){const res=await fetch(`${endpoint}?select=records&id=eq.1`,{headers});if(!res.ok)return json(502,{error:'อ่านข้อมูลจากฐานข้อมูลไม่สำเร็จ'});const rows=await res.json();return json(200,{records:Array.isArray(rows?.[0]?.records)?rows[0].records:[]})}
  let body;try{body=JSON.parse(event.body||'{}')}catch{return json(400,{error:'ข้อมูลบันทึกไม่ถูกต้อง'})}
  if(body.action==='clear'){
   if(payload.role!=='admin')return json(403,{error:'เฉพาะผู้ดูแลระบบเท่านั้นที่ล้างข้อมูลทั้งหมดได้'});
   const res=await fetch(`${endpoint}?id=eq.1`,{method:'PATCH',headers:{...headers,Prefer:'return=minimal'},body:JSON.stringify({records:[],updated_at:new Date().toISOString()})});
   if(!res.ok){console.error('Supabase clear failed',res.status,await res.text());return json(502,{error:'ล้างข้อมูลในฐานข้อมูลไม่สำเร็จ'})}return json(200,{ok:true,cleared:true});
  }
  if(payload.role!=='inspector'&&payload.role!=='admin')return json(403,{error:'ไม่มีสิทธิ์บันทึกข้อมูล'});
  if(!Array.isArray(body.records)||body.records.length===0)return json(400,{error:'ไม่พบรายการข้อมูลที่ต้องการบันทึก'});
  if(Buffer.byteLength(JSON.stringify(body.records),'utf8')>7_000_000)return json(413,{error:'ข้อมูลรวมมีขนาดใหญ่เกินไป กรุณาลดขนาดรูปภาพ'});
  const res=await fetch(`${endpoint}?on_conflict=id`,{method:'POST',headers:{...headers,Prefer:'resolution=merge-duplicates,return=minimal'},body:JSON.stringify({id:1,records:body.records,updated_at:new Date().toISOString()})});
  if(!res.ok){console.error('Supabase write failed',res.status,await res.text());return json(502,{error:'บันทึกข้อมูลลงฐานข้อมูลไม่สำเร็จ'})}return json(200,{ok:true});
 }catch(e){console.error('state function error',e);return json(500,{error:'เกิดข้อผิดพลาดระหว่างติดต่อฐานข้อมูล'})}
};
