-- รันใน Supabase SQL Editor เพื่อกำหนดรหัสผู้ตรวจร่วมกันเป็น SAFE2026
-- หากต้องการเปลี่ยนรหัส ให้แก้ข้อความ SAFE2026 ด้านล่างก่อนรัน
create extension if not exists pgcrypto with schema extensions;
create table if not exists public.inspector_access_config (id integer primary key check (id = 1), code_hash text not null, updated_at timestamptz not null default now());
alter table public.inspector_access_config enable row level security;
revoke all on public.inspector_access_config from anon, authenticated;
insert into public.inspector_access_config (id, code_hash) values (1, encode(extensions.digest('SAFE2026','sha256'),'hex')) on conflict (id) do update set code_hash=excluded.code_hash, updated_at=now();
